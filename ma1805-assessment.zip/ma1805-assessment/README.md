Lab Rats
Get to the end
Survey the odds
Carry on through...

Labrats is an experimental interactive project, similarly exploring the theme of a game that subverts established game mechanics. The theme of surveillance struck my eye the most.


Inspiration:
The digital and physical culture of labwork involving mice and rats was my initial inspiration of this project, as well as personal inspiration from my life and my real-life labradoodle puppies - who i nickname labrats. 

Moreover, the style of this, 'corrupted', game brings life from old-school pacman and typical maze puzzles. 'pacman' on google. 

Challenges
Unfortunately, I do believe this work could have been polished aesthetically and mechanically, but my theme is shown correctly. 
Although my code could have been refined, the overall premise of my idea works with the idea of corrupted game mechanics and subverting the natural style. With my own painted background to ground this idea of, 'unfinished'. 

Try and get to the end! See what challenges *you* may face...



